from django.contrib import admin
from .models import pubg_registered_id
from .models import pubg_registered_id_10_taka

admin.site.register (pubg_registered_id)
admin.site.register (pubg_registered_id_10_taka)
